                    IMPORTANT INFORMATION FOR DBASE III+ CODERS

If you want to modify any files, you must use a plain text based editor such as
EDLIN (MS DOS 3.3), EDIT, NOTEPAD etc. DO NOT USE A WORD PROCESSOR that inserts
formatting codes into the file, otherwise you are risking disaster.

 

 